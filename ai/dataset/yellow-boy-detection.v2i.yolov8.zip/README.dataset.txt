# yellow-boy-detection > 2026-01-23 10:51am
https://universe.roboflow.com/ismc-6pk3b/yellow-boy-detection

Provided by a Roboflow user
License: CC BY 4.0

